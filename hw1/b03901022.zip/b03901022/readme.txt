### the file include 5 matlab files(*.m):
        pb1.m
        pb2_1.m
        pb2_2.m
        pb2_3.m
        pb3.m

    1. to get the result of requirement 1
        type the command line in matlab: pb1

    2. to get the result of requirement 2.(a).(i)
        type the command line in matlab: pb2_1

    3. to get the result of requirement 2.(a).(ii)
        type the command line in matlab: pb2_2

    4. to get the result of requirement 2.(b)
        type the command line in matlab: pb2_3

    5. to get the result of requirement 3.
        type the command line in matlab: pb3

###
